package projeto;

public class Aluno {
    private int matricula;
    private String nome;
    private PresencaInfo presencaInfo;

    public Aluno(int matricula, String nome) {
        this.matricula = matricula;
        this.nome = nome;
        this.presencaInfo = new PresencaInfo();
    }

    public int getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public PresencaInfo getPresencaInfo() {
        return presencaInfo;
    }

    @Override
    public String toString() {
        return nome;
    }
}
