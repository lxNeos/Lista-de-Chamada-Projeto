package projeto;

 

import javax.swing.*;

import javax.swing.table.DefaultTableModel;

import java.awt.*;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;

import java.sql.*;

import java.util.HashMap;

import java.util.Map;

 

public class ListadeChamadaGUI extends JFrame {

 

    private JTable table;

    private DefaultTableModel tableModel;

    private Connection connection;

    private DefaultListModel<Aluno> model;

    private Map<Aluno, PresencaInfo> presencasMap;

    private String nomeCurso = "Ciência da Computação";

    private String nomeProfessor = "Henrique Nogueira";

    public ListadeChamadaGUI() {

        setTitle("Lista de Chamada");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setSize(600, 400);

        setLocationRelativeTo(null);

 

        initComponents();

        setupDatabaseConnection();

        reloadAlunosFromDatabase();  

        addHeaderLabels();

        addTable();

        addToolbar();

 

        // Configurar fechamento da janela

        addWindowListener(new WindowAdapter() {

            public void windowClosing(WindowEvent e) {

                super.windowClosing(e);

                savePresencasToDatabase();

            }

        });

    }

 

    private void initComponents() {

        model = new DefaultListModel<>();

        presencasMap = new HashMap<>();

 

        tableModel = new DefaultTableModel(new Object[][]{}, new String[]{"Matrícula", "Nome", "Presença", "Falta", "Abonada"}) {

            @Override

            public boolean isCellEditable(int row, int column) {

                // Permitir a edição apenas nas colunas de presença, falta e abonada

                return column > 1;

            }

        };

 

        table = new JTable(tableModel);

        table.getColumnModel().getColumn(2).setCellEditor(new RadioButtonCellEditor());

        table.getColumnModel().getColumn(3).setCellEditor(new RadioButtonCellEditor());

        table.getColumnModel().getColumn(4).setCellEditor(new RadioButtonCellEditor());

        table.getColumnModel().getColumn(2).setCellRenderer(new RadioButtonRenderer());

        table.getColumnModel().getColumn(3).setCellRenderer(new RadioButtonRenderer());

        table.getColumnModel().getColumn(4).setCellRenderer(new RadioButtonRenderer());

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

 

        getContentPane().setLayout(new BorderLayout());

        getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

    }

 

    private void setupDatabaseConnection() {

        String jdbcUrl = "jdbc:mysql://localhost:3306/localhost";

        String username = "root";

        String password = "nefertiti12345";

 

        try {

            Class.forName("com.mysql.jdbc.Driver");

            connection = DriverManager.getConnection(jdbcUrl, username, password);

            System.out.println("Conexão com o banco de dados estabelecida com sucesso!");

        } catch (ClassNotFoundException e) {

            System.err.println("Driver do MySQL não encontrado!");

            e.printStackTrace();

        } catch (SQLException e) {

            System.err.println("Erro ao conectar-se ao banco de dados: " + e.getMessage());

            e.printStackTrace();

        }

    }

 

    private void loadAlunosFromDatabase() {
        try {
            String sql = "SELECT matricula, nome, presenca, falta, abonada FROM alunos";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int matricula = resultSet.getInt("matricula");
                String nome = resultSet.getString("nome");
                boolean presenca = resultSet.getBoolean("presenca");
                boolean falta = resultSet.getBoolean("falta");
                boolean abonada = resultSet.getBoolean("abonada");

                Aluno aluno = new Aluno(matricula, nome);
                model.addElement(aluno);

                PresencaInfo presencaInfo = new PresencaInfo();
                presencaInfo.setPresenca(presenca);
                presencaInfo.setFalta(falta);
                presencaInfo.setAbonada(abonada);
                presencasMap.put(aluno, presencaInfo);

                tableModel.addRow(new Object[]{aluno.getMatricula(), aluno.getNome(),
                        presencaInfo.isPresenca(), presencaInfo.isFalta(), presencaInfo.isAbonada()});
            }

            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.err.println("Erro ao carregar os alunos do banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }

 

    private void addHeaderLabels() {

         JPanel headerPanel = new JPanel(new GridBagLayout());

 

            GridBagConstraints constraints = new GridBagConstraints();

            constraints.gridx = 0;

            constraints.gridy = 0;

            constraints.anchor = GridBagConstraints.WEST;

 

            JLabel labelCurso = new JLabel("Curso: " + nomeCurso);

            headerPanel.add(labelCurso, constraints);

 

            constraints.gridy = 1;

 

            JLabel labelProfessor = new JLabel("Professor: " + nomeProfessor);

            headerPanel.add(labelProfessor, constraints);

 

            getContentPane().add(headerPanel, BorderLayout.NORTH);

    }

 

    private void addTable() {

        JPanel panel = new JPanel(new BorderLayout());

        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        getContentPane().add(panel, BorderLayout.CENTER);

    }

 

    private void addToolbar() {

        JToolBar toolbar = new JToolBar();

        JButton saveButton = new JButton("Salvar");

        JButton addButton = new JButton("Adicionar Aluno");

        JButton removeButton = new JButton("Remover Aluno");

 

        saveButton.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                savePresencasToDatabase();

            }

        });

 

        addButton.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                addAluno();

            }

        });

 

        removeButton.addActionListener(new ActionListener() {

            @Override

            public void actionPerformed(ActionEvent e) {

                removeAluno();

            }

        });

 

        toolbar.add(saveButton);

        toolbar.add(addButton);

        toolbar.add(removeButton);

 

        getContentPane().add(toolbar, BorderLayout.SOUTH);

    }

 

    private void savePresencasToDatabase() {
        try {
            String updateSql = "UPDATE alunos SET presenca = ?, falta = ?, abonada = ? WHERE matricula = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateSql);

            for (int i = 0; i < table.getRowCount(); i++) {
                int matricula = (int) table.getValueAt(i, 0);
                boolean presenca = (boolean) table.getValueAt(i, 2);
                boolean falta = (boolean) table.getValueAt(i, 3);
                boolean abonada = (boolean) table.getValueAt(i, 4);

                updateStatement.setBoolean(1, presenca);
                updateStatement.setBoolean(2, falta);
                updateStatement.setBoolean(3, abonada);
                updateStatement.setInt(4, matricula);

                updateStatement.executeUpdate();

                // Atualiza as informações de presença no presencasMap
                Aluno aluno = model.getElementAt(i);
                PresencaInfo presencaInfo = presencasMap.get(aluno);
                presencaInfo.setPresenca(presenca);
                presencaInfo.setFalta(falta);
                presencaInfo.setAbonada(abonada);
            }

            updateStatement.close();

            System.out.println("Presenças salvas no banco de dados com sucesso!");
        } catch (SQLException e) {
            System.err.println("Erro ao salvar as presenças no banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }

 

    private void addAluno() {

        String nome = JOptionPane.showInputDialog(this, "Digite o nome do aluno:", "Adicionar Aluno", JOptionPane.PLAIN_MESSAGE);

        if (nome != null && !nome.trim().isEmpty()) {

            try {

                String selectSql = "SELECT MAX(matricula) FROM alunos";

                PreparedStatement selectStatement = connection.prepareStatement(selectSql);

                ResultSet resultSet = selectStatement.executeQuery();

 

                int lastMatricula = 0;

                if (resultSet.next()) {

                    lastMatricula = resultSet.getInt(1);

                }

 

                int newMatricula = lastMatricula + 1;

 

                String insertSql = "INSERT INTO alunos (matricula, nome) VALUES (?, ?)";

                PreparedStatement insertStatement = connection.prepareStatement(insertSql);

                insertStatement.setInt(1, newMatricula);

                insertStatement.setString(2, nome);

 

                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {

                    Aluno aluno = new Aluno(newMatricula, nome);

                    model.addElement(aluno);

 

                    PresencaInfo presencaInfo = new PresencaInfo();

                    presencasMap.put(aluno, presencaInfo); // Adiciona o aluno e suas informações de presença ao presencasMap

 

                    tableModel.addRow(new Object[]{aluno.getMatricula(), aluno.getNome(),

                            presencaInfo.isPresenca(), presencaInfo.isFalta(), presencaInfo.isAbonada()});

                }

 

                resultSet.close();

                selectStatement.close();

                insertStatement.close();

            } catch (SQLException e) {

                System.err.println("Erro ao adicionar o aluno no banco de dados: " + e.getMessage());

                e.printStackTrace();

            }

        }

    }

    private void reloadAlunosFromDatabase() {

        model.clear();

        presencasMap.clear();

        tableModel.setRowCount(0);

 

        loadAlunosFromDatabase();

    }

 

    private void removeAluno() {

        int selectedRowIndex = table.getSelectedRow();

        if (selectedRowIndex >= 0) {

            Aluno aluno = (Aluno) model.getElementAt(selectedRowIndex); // Obtém o objeto Aluno do DefaultListModel

            int matricula = aluno.getMatricula();

 

            int option = JOptionPane.showConfirmDialog(this, "Deseja remover o aluno selecionado?", "Remover Aluno",

                    JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {

                try {

                    String deleteSql = "DELETE FROM alunos WHERE matricula = ?";

                    PreparedStatement deleteStatement = connection.prepareStatement(deleteSql);

                    deleteStatement.setInt(1, matricula);

                    deleteStatement.executeUpdate();

                    deleteStatement.close();

 

                    // Remover o aluno da interface

                    model.removeElement(aluno); // Remove o aluno do DefaultListModel

                    presencasMap.remove(aluno); // Remove as informações de presença do presencasMap

                    tableModel.removeRow(selectedRowIndex);

 

                    System.out.println("Aluno removido do banco de dados com sucesso!");

 

                    // Salvar as alterações no banco de dados

                    savePresencasToDatabase();

                } catch (SQLException e) {

                    System.err.println("Erro ao remover o aluno do banco de dados: " + e.getMessage());

                    e.printStackTrace();

                }

            }

        } else {

            JOptionPane.showMessageDialog(this, "Selecione um aluno para remover!", "Remover Aluno", JOptionPane.WARNING_MESSAGE);

        }

    }

 

}