package projeto;

 

import com.google.gson.Gson;

import com.google.gson.GsonBuilder;

import java.io.FileReader;

import java.io.FileWriter;

import java.io.IOException;

 

import javax.swing.ButtonGroup;

import javax.swing.JRadioButton;

 

public class PresencaInfo {

    private boolean presenca;

    private boolean falta;

    private boolean abonada;

 

    private ButtonGroup buttonGroup;

 

    public PresencaInfo() {

        buttonGroup = new ButtonGroup();

    }

 

    public boolean isPresenca() {

        return presenca;

    }

 

    public void setPresenca(boolean presenca) {

        this.presenca = presenca;

    }

 

    public boolean isFalta() {

        return falta;

    }

 

    public void setFalta(boolean falta) {

        this.falta = falta;

    }

 

    public boolean isAbonada() {

        return abonada;

    }

 

    public void setAbonada(boolean abonada) {

        this.abonada = abonada;

    }

 

    public JRadioButton createPresencaRadioButton() {

        JRadioButton radioButton = new JRadioButton();

        buttonGroup.add(radioButton);

        return radioButton;

    }

 

    public JRadioButton createFaltaRadioButton() {

        JRadioButton radioButton = new JRadioButton();

        buttonGroup.add(radioButton);

        return radioButton;

    }

 

    public JRadioButton createAbonadaRadioButton() {

        JRadioButton radioButton = new JRadioButton();

        buttonGroup.add(radioButton);

        return radioButton;

    }

 

    public void saveData(String filePath) {

        try (FileWriter writer = new FileWriter(filePath)) {

            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            gson.toJson(this, writer);

        } catch (IOException e) {

            e.printStackTrace();

        }

    }

 

    public static PresencaInfo loadData(String filePath) {

        try (FileReader reader = new FileReader(filePath)) {

            Gson gson = new Gson();

            return gson.fromJson(reader, PresencaInfo.class);

        } catch (IOException e) {

            e.printStackTrace();

        }

        return null;

    }

}