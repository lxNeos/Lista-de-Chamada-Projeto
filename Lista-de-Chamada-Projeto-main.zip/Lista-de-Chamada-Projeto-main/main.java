
package projeto;
 

import java.awt.event.WindowAdapter;

import java.awt.event.WindowEvent;

 

import javax.swing.SwingUtilities;

 

public class main {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            ListadeChamadaGUI gui = new ListadeChamadaGUI();

            gui.setVisible(true);

        });

    }

}




 


