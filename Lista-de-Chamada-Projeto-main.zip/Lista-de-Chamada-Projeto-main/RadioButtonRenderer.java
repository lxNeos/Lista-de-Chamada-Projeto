package projeto;

import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import java.awt.Component;

public class RadioButtonRenderer implements TableCellRenderer {
    private final JRadioButton radioButton;

    public RadioButtonRenderer() {
        radioButton = new JRadioButton();
        radioButton.setHorizontalAlignment(JRadioButton.CENTER);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                   boolean hasFocus, int row, int column) {
        if (value != null && value instanceof Boolean) {
            radioButton.setSelected((Boolean) value);
        } else {
            radioButton.setSelected(false);
        }
        return radioButton;
    }
}
