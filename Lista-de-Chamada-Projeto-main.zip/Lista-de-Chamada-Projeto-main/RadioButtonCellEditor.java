package projeto;

 

import javax.swing.AbstractCellEditor;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

 

public class RadioButtonCellEditor extends AbstractCellEditor implements TableCellEditor {
    private JRadioButton radioButton;

 

    public RadioButtonCellEditor() {
        radioButton = new JRadioButton();
        radioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopCellEditing();
            }
        });
    }

 

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        radioButton.setSelected((Boolean) value);
        return radioButton;
    }

 

    @Override
    public Object getCellEditorValue() {
        return radioButton.isSelected();
    }
}