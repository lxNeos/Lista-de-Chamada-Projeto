package projeto;

 

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.ListCellRenderer;
import java.awt.Component;
import java.awt.GridLayout;
import java.util.Map;

 

public class AlunoListCellRenderer extends JPanel implements ListCellRenderer<Aluno> {
    private JPanel panel;
    private JLabel labelNome;
    private Map<Aluno, PresencaInfo> presencasMap;

 

    public AlunoListCellRenderer(Map<Aluno, PresencaInfo> presencasMap) {
        this.presencasMap = presencasMap;

 

        panel = new JPanel();
        panel.setLayout(new GridLayout(1, 5));

 

        labelNome = new JLabel();

 

        panel.add(labelNome);
    }

 

    @Override
    public Component getListCellRendererComponent(JList<? extends Aluno> list, Aluno aluno, int index,
                                                  boolean isSelected, boolean cellHasFocus) {
        labelNome.setText(aluno.getNome());

 

        panel.removeAll(); // Remove todos os componentes do painel

 

        PresencaInfo presencaInfo = presencasMap.get(aluno);
        JRadioButton radioButtonPresenca = presencaInfo.createPresencaRadioButton();
        JRadioButton radioButtonFalta = presencaInfo.createFaltaRadioButton();
        JRadioButton radioButtonAbonada = presencaInfo.createAbonadaRadioButton();

 

        radioButtonPresenca.setText("Presença");
        radioButtonPresenca.setSelected(presencaInfo.isPresenca());
        radioButtonFalta.setText("Falta");
        radioButtonFalta.setSelected(presencaInfo.isFalta());
        radioButtonAbonada.setText("Abonada");
        radioButtonAbonada.setSelected(presencaInfo.isAbonada());

 

        panel.add(radioButtonPresenca);
        panel.add(radioButtonFalta);
        panel.add(radioButtonAbonada);

 

        return panel;
    }
}